    export const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:5000";
    export const SSE_BASE = import.meta.env.VITE_SSE_BASE || "http://localhost:5000";
